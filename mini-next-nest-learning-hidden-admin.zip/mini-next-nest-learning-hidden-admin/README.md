# Mini Next.js + NestJS Learning Project (Hidden Admin Path)

- Frontend: Next.js (App Router)
- Backend: NestJS (REST)
- ORM: Prisma
- DB: SQLite
- Uploads: Local (Multer)

## Hidden admin path
Access admin via: `/qingcheng/omijcerceroimj1qaz23qs/qinchengAdm.html` (rewritten to `/admin`).

## Quick start
See steps inside apps/api and apps/web package.json scripts.
