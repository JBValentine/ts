
import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as express from 'express';
import * as path from 'path';
import * as cors from 'cors';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.use(cors({ origin: ['http://localhost:3000'], credentials: true }));
  app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));
  await app.listen(3001);
  console.log('API ready on http://localhost:3001');
}
bootstrap();
