
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class ListingService {
  constructor(private prisma: PrismaService) {}

  async list() {
    return this.prisma.listing.findMany({
      include: { region: true, medias: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(data: { title: string; regionSlug: string; areaText?: string }) {
    let region = await this.prisma.region.findUnique({ where: { slug: data.regionSlug } });
    if (!region) {
      region = await this.prisma.region.create({ data: { slug: data.regionSlug, name: data.regionSlug.toUpperCase() } });
    }
    return this.prisma.listing.create({
      data: { title: data.title, areaText: data.areaText, regionId: region.id },
    });
  }

  async byId(id: string) {
    return this.prisma.listing.findUnique({
      where: { id },
      include: { region: true, medias: { orderBy: { order: 'asc' } } },
    });
  }
}
