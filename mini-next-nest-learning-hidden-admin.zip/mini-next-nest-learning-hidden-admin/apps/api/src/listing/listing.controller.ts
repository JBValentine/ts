
import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ListingService } from './listing.service';

@Controller('listings')
export class ListingController {
  constructor(private service: ListingService) {}

  @Get()
  findMany() { return this.service.list(); }

  @Get(':id')
  findOne(@Param('id') id: string) { return this.service.byId(id); }

  @Post()
  create(@Body() dto: { title: string; regionSlug: string; areaText?: string }) {
    return this.service.create(dto);
  }
}
