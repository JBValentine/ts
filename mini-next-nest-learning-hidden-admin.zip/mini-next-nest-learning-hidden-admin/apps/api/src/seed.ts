
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
async function main() {
  const regions = ['central','east','west','north','geylang','massage'];
  for (const slug of regions) {
    await prisma.region.upsert({ where: { slug }, update: {}, create: { slug, name: slug.toUpperCase() } });
  }
  const r = await prisma.region.findUnique({ where: { slug: 'central' } });
  if (r) await prisma.listing.create({ data: { title: 'Sample Listing', regionId: r.id, areaText: 'Downtown', isFeatured: true } });
  console.log('Seed done.');
}
main().finally(() => prisma.$disconnect());
