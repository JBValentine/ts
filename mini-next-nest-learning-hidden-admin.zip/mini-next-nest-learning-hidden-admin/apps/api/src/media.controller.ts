
import { Controller, Post, UseInterceptors, UploadedFile, Body, Delete, Param } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname, join } from 'path';
import { PrismaService } from './prisma.service';
import { nanoid } from 'nanoid';

@Controller('media')
export class MediaController {
  constructor(private prisma: PrismaService) {}

  @Post('upload-image')
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      destination: join(__dirname, '..', 'uploads'),
      filename: (_req, file, cb) => { cb(null, nanoid(10) + extname(file.originalname)); },
    }),
    limits: { fileSize: 10 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
      if (!file.mimetype.startsWith('image/')) return cb(new Error('Only images allowed'), false);
      cb(null, true);
    },
  }))
  async uploadImage(@UploadedFile() file: Express.Multer.File, @Body() dto: { listingId: string }) {
    const listing = await this.prisma.listing.findUnique({ where: { id: dto.listingId } });
    if (!listing) throw new Error('Listing not found');
    const relPath = `/uploads/${file.filename}`;
    const media = await this.prisma.media.create({ data: { listingId: listing.id, kind: 'IMAGE', url: relPath } });
    return media;
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    await this.prisma.media.delete({ where: { id } });
    return { ok: true };
  }
}
