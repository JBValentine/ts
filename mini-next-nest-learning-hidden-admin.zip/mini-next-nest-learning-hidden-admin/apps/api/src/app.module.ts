
import { Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { ListingController } from './listing/listing.controller';
import { ListingService } from './listing/listing.service';
import { MediaController } from './media.controller';

@Module({
  controllers: [ListingController, MediaController],
  providers: [PrismaService, ListingService],
})
export class AppModule {}
