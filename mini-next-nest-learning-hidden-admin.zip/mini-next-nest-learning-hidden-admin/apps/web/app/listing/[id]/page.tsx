
import { API_BASE } from '../../../lib/api';

async function getListing(id: string) {
  const res = await fetch(API_BASE + '/listings/' + id, { cache: 'no-store' });
  return res.json();
}

export default async function ListingPage({ params }: { params: { id: string }}) {
  const l = await getListing(params.id);
  return (
    <main style={{maxWidth: 800, margin: '20px auto', padding: 16}}>
      <a href="/">← Back</a>
      <h1 style={{marginTop:12}}>{l.title} <small style={{color:'#888'}}>#{l.code}</small></h1>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(240px,1fr))', gap:12}}>
        {l.medias?.map((m: any) => (
          <img key={m.id} src={`http://localhost:3001${m.url}`} style={{width:'100%', borderRadius:8}}/>
        ))}
      </div>
      <p style={{color:'#666', marginTop:12}}>{l.region?.name}{l.areaText ? ' · '+l.areaText : ''}</p>
    </main>
  )
}
