
import { API_BASE } from '../lib/api';

async function getListings() {
  const res = await fetch(API_BASE + '/listings', { cache: 'no-store' });
  return res.json();
}

export default async function Home() {
  const listings = await getListings();
  return (
    <main style={{maxWidth: 960, margin: '20px auto', padding: 16}}>
      <h1>Mini Directory</h1>
      <p><a href="/qingcheng/omijcerceroimj1qaz23qs/qinchengAdm.html">Go to Admin</a></p>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(220px,1fr))', gap:12}}>
        {listings.map((l: any) => (
          <a key={l.id} href={`/listing/${l.id}`} style={{border:'1px solid #ddd', borderRadius:12, padding:12, textDecoration:'none', color:'#111'}}>
            <div style={{position:'relative', paddingBottom:'66%', background:'#f4f4f4', borderRadius:8, overflow:'hidden', marginBottom:8}}>
              {l.medias?.[0] ? <img src={`http://localhost:3001${l.medias[0].url}`} style={{position:'absolute', inset:0, width:'100%', height:'100%', objectFit:'cover'}}/> : null}
            </div>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <strong>{l.title}</strong>
              <small>#{l.code}</small>
            </div>
            <div style={{color:'#666'}}>{l.region?.name}{l.areaText ? ' · '+l.areaText : ''}</div>
          </a>
        ))}
      </div>
    </main>
  )
}
