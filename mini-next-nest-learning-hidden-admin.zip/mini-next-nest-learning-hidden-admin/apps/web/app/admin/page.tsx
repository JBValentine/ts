
'use client';

import { API_BASE } from '../../lib/api';
import { useEffect, useState } from 'react';

export default function Admin() {
  const [title, setTitle] = useState('');
  const [region, setRegion] = useState('central');
  const [listings, setListings] = useState<any[]>([]);
  const [selected, setSelected] = useState<string>('');

  async function reload() {
    const res = await fetch(API_BASE + '/listings');
    const data = await res.json();
    setListings(data);
  }
  useEffect(() => { reload(); }, []);

  async function createListing() {
    const res = await fetch(API_BASE + '/listings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, regionSlug: region })
    });
    await res.json();
    setTitle('');
    await reload();
  }

  async function uploadImage(file: File) {
    if (!selected) return alert('Select a listing first');
    const fd = new FormData();
    fd.append('file', file);
    fd.append('listingId', selected);
    const res = await fetch(API_BASE + '/media/upload-image', { method: 'POST', body: fd });
    if (!res.ok) alert('Upload failed');
    await reload();
  }

  return (
    <main style={{maxWidth: 960, margin:'20px auto', padding:16}}>
      <a href="/">← Home</a>
      <h1>Admin</h1>

      <section style={{border:'1px solid #ddd', padding:12, borderRadius:8, marginBottom:16}}>
        <h3>Create Listing</h3>
        <div style={{display:'flex', gap:8}}>
          <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
          <select value={region} onChange={e=>setRegion(e.target.value)}>
            <option value="central">central</option>
            <option value="east">east</option>
            <option value="west">west</option>
            <option value="north">north</option>
            <option value="geylang">geylang</option>
            <option value="massage">massage</option>
          </select>
          <button onClick={createListing}>Create</button>
        </div>
      </section>

      <section style={{border:'1px solid #ddd', padding:12, borderRadius:8, marginBottom:16}}>
        <h3>Upload Image to Selected Listing</h3>
        <input type="file" accept="image/*" onChange={e=>{const f=e.target.files?.[0]; if(f) uploadImage(f)}} />
      </section>

      <section>
        <h3>Listings</h3>
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(220px,1fr))', gap:12}}>
          {listings.map(l => (
            <div key={l.id} style={{border:'1px solid #ddd', borderRadius:8, padding:8, background:selected===l.id?'#eef':'#fff'}} onClick={()=>setSelected(l.id)}>
              <div style={{fontWeight:600}}>{l.title}</div>
              <small>{l.region?.name} · #{l.code}</small>
              <div style={{display:'flex', gap:6, marginTop:6, flexWrap:'wrap'}}>
                {l.medias?.map((m:any)=> (
                  <img key={m.id} src={`http://localhost:3001${m.url}`} style={{width:60, height:60, objectFit:'cover', borderRadius:6}}/>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
