
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { serverActions: true },
  async rewrites() {
    return [
      {
        source: '/qingcheng/omijcerceroimj1qaz23qs/qinchengAdm.html',
        destination: '/admin',
      },
    ];
  },
  async headers() {
    return [
      {
        source: '/qingcheng/omijcerceroimj1qaz23qs/qinchengAdm.html',
        headers: [{ key: 'X-Robots-Tag', value: 'noindex, nofollow, noarchive' }],
      },
    ];
  },
};
module.exports = nextConfig;
